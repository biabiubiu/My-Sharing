package box.spider.scrapy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrapyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScrapyApplication.class, args);
	}

}
