import request from '@/utils/request'

export function login(data) {
  let ret = ''
  for (const d in data) {
    ret += `${encodeURIComponent(d)}=${encodeURIComponent(data[d])}&`
  }
  return request({
    url: '/gateway/gateway/auth/login',
    method: 'post',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: ret
  })
}

export function getInfo() {
  return request({
    url: '/gateway/gateway/auth//roles',
    method: 'get'
  })
}

export function logout() {
  return request({
    url: '/server/auth/oauth/logout',
    method: 'post'
  })
}

export function getAllUserByPage(pageInfo) {
  return request({
    url: `/server/user/user_manager/get-all/${pageInfo.pageNum}/${pageInfo.pageSize}`,
    method: 'get'
  })
}

export function getAllRoleByPage(pageInfo) {
  return request({
    url: `/server/user/role_manager/get-all/${pageInfo.pageNum}/${pageInfo.pageSize}`,
    method: 'get'
  })
}
