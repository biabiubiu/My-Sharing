<template>
  <div class="dashboard-container">
    <div class="dashboard-text">name: {{ $t('main.home') }}</div>
    <div>
      {{ this.$store.state.app.device }}
    </div>
    <br>
    <el-button @click="changeLang">修改语言: {{ lang }}</el-button>
    <el-button @click="open">点击打开 Message Box</el-button>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// import Layout from '@/layout/index'
export default {
  name: 'Home',
  data() {
    return {
      lang: 'zh_CN'
    }
  },
  computed: {
    ...mapGetters([
      'name'
    ])
  },
  methods: {
    changeLang() {
      this.lang = this.lang === 'zh_CN' ? 'en_US' : 'zh_CN'
      this.$i18n.locale = this.lang
    },
    open() {
      this.$alert('这是一段内容', '标题名称', {
        callback: action => {
          this.$message({
            type: 'info',
            message: `action: ${action}`
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
