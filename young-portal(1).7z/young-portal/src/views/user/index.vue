<template>
  <div class="app-container">
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      border
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        align="center"
        type="selection"
        width="50"
      />
      <el-table-column
        align="center"
        prop="username"
        :label="this.$t('label.user.index.name')"
        width="180"
      />
      <el-table-column
        align="center"
        prop="nick"
        :label="this.$t('label.user.index.nick')"
        width="180"
      />
      <el-table-column
        align="center"
        prop="clientId"
        :label="this.$t('label.user.index.clientId')"
        width="180"
      />
      <el-table-column
        align="center"
        prop="phone"
        :label="this.$t('label.user.index.phone')"
        width="180"
      />
      <el-table-column
        align="center"
        prop="email"
        :label="this.$t('label.user.index.email')"
        width="180"
      />
      <el-table-column
        align="center"
        :label="this.$t('label.user.index.loginTime')"
        width="180"
      >
        <template slot-scope="scope">{{ scope.row.loginTime }}</template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </div>
</template>

<script>
import { getAllUserByPage } from '@/api/user'

export default {
  name: 'Index',
  data() {
    return {
      pageSizes: [10, 20, 40, 50, 100],
      tableData: [],
      pageInfo: {
        pageNum: 0,
        pageSize: 10
      },
      currentPage: 1,
      totalSize: 0
    }
  },
  created() {
    this.getAllUser()
  },
  methods: {
    getAllUser() {
      getAllUserByPage(this.pageInfo).then(res => {
        const resData = res.data.data
        this.tableData = resData.tlist
        this.totalSize = resData.total
      })
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    }, handleSizeChange(val) {
      this.pageInfo.pageSize = val
      this.getAllUser()
    },
    handleCurrentChange(val) {
      this.pageInfo.pageNum = val - 1
      this.getAllUser()
    }
  }
}
</script>

<style lang="scss">

</style>
