<template>
  <div class="app-container">
    <h1>我的世界起始页面</h1>
  </div>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style scoped>

</style>
