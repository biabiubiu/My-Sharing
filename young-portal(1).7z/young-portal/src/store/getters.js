const getters = {
  sidebar: state => state.app.sidebar,
  size: state => state.app.size,
  device: state => state.app.device,
  visitedViews: state => state.tagsView.visitedViews,
  cachedViews: state => state.tagsView.cachedViews,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  permission_routes: state => state.permission.routes,
  name: state => state.user.name,
  errorLogs: state => state.errorLog.logs,
  title: state => state.settings.title,
  lang: state => state.settings.lang,
  addRoutes: state => state.permission.addRoutes,
  isRefresh: state => state.permission.isRefresh
}
export default getters
