import { asyncRoutes, constantRoutes } from '@/router'

/**
 * Filter asynchronous routing tables by recursion
 * @param routes asyncRoutes
 * @param menus
 */
export const filterAsyncRoutes = (menus) => {
  const res = []
  menus.sort(function(a, b) {
    return a.showOrder - b.showOrder
  })
  menus.forEach(menu => {
    const {
      path,
      component,
      name,
      meta,
      redirect,
      hidden
    } = menu

    if (path) {
      let { children } = menu
      if (children && children instanceof Array) {
        children = filterAsyncRoutes(children)
      }

      const fmRouter = {
        path: path,
        name: name,
        meta: JSON.parse(meta),
        children: children,
        redirect: redirect,
        hidden: hidden,
        component: (resolve) => {
          if (component.startsWith('@')) {
            require(['@/layout/index.vue'], resolve)
          } else {
            require([`../../views${component}.vue`], resolve)
          }
        }
      }
      res.push(fmRouter)
    }
  })
  return res
}

const state = {
  routes: [],
  addRoutes: [],
  isRefresh: true
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
    state.routes = constantRoutes.concat(routes)
    state.isRefresh = false
  }
}

const actions = {
  generateRoutes({ commit }, menus) {
    return new Promise(resolve => {
      let accessedRoutes = filterAsyncRoutes(menus)
      accessedRoutes = accessedRoutes.concat(asyncRoutes)
      commit('SET_ROUTES', accessedRoutes)
      resolve(accessedRoutes)
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
