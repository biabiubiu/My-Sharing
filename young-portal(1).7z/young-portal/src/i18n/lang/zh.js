// 国际化中文
module.exports = {
  // 主要的
  main: {
    home: '首页',
    zh_CN: '中文',
    en_US: '英文'
  },
  action: {
    login: {
      ok: '登陆成功.'
    },
    logout: {
      ok: '注销成功',
      error: {
        title: '确认登出',
        msg: '您已退出，您可以选择停留在此页面，或重新登录',
        confirm: '重新登陆',
        cancel: '留在该页面'
      }
    }
  },
  // 菜单
  menu: {
    user: {
      parent: '权限管理',
      index: '用户列表',
      role: '角色详情'
    },
    mc: {
      parent: '我的世界',
      index: '信息中心',
      server: '服务器管理'
    }
  },
  // 操作,按钮
  option: {
    login: '登录',
    logout: '注销'
  },
  // 标签
  label: {
    user: {
      index: {
        name: '用户名',
        clientId: '客户端',
        phone: '电话',
        email: '电子邮件',
        loginTime: '登录时间',
        nick: '昵称'
      },
      info: {
        name: '角色名',
        description: '角色描述',
        createTime: '创建时间',
        updateTime: '更新时间'
      }
    }
  }
}
