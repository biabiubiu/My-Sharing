// 国际化英语
module.exports = {
  // 主要的
  main: {
    home: 'Home',
    zh_CN: 'Chinese',
    en_US: 'English'
  },
  action: {
    login: {
      ok: 'login successful.'
    },
    logout: {
      ok: 'logout successful',
      error: {
        title: 'Confirm logout',
        msg: 'You have been logged out, you can stay on this page, or log in again',
        confirm: 'ReLogin',
        cancel: 'Stay On'
      }
    }
  },
  // 菜单
  menu: {
    user: {
      parent: 'Authority Management',
      index: 'User List',
      role: 'Role Info'
    },
    mc: {
      parent: 'Minecraft',
      index: 'Info Center',
      server: 'Server Manager'
    }
  },
  // 操作,按钮
  option: {
    login: 'login',
    logout: 'logout'
  },
  // 标签

  label: {
    user: {
      index: {
        name: 'name',
        clientId: 'clientId',
        phone: 'phone',
        email: 'email',
        loginTime: 'loginTime',
        nick: 'nick'
      },
      info: {
        name: 'name',
        description: 'description',
        createTime: 'createTime',
        updateTime: 'updateTime'
      }
    }
  }
}
