<template>
  <el-dropdown trigger="click" @command="selectLang">
    <div>
      <svg-icon class-name="language-icon" icon-class="language" />
    </div>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item
        v-for="item in langs"
        :key="item.value"
        :disabled="nowLang===item.value"
        :command="item.value"
      >
        {{ $t(item.label) }}
      </el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
export default {
  name: 'Index',
  data() {
    return {
      langs: [
        { label: 'main.zh_CN', value: 'zh_CN' },
        { label: 'main.en_US', value: 'en_US' }
      ]
    }
  },
  computed: {
    nowLang() {
      return this.$i18n.locale
    },
    title() {
      return this.$store.getters.title
    }
  },
  methods: {
    selectLang(lang) {
      this.$i18n.locale = lang

      const meta = this.$route.meta
      if (meta) {
        console.dir(meta.title)
        document.title = `${this.$t(meta.title)} | ${this.title}`
      }
      this.$message({
        message: 'operator successful...',
        type: 'success'
      })
    }
  }
}
</script>

<style scoped>

</style>
