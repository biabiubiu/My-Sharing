const userConst = {
  SSO_FLAG: 'ssoFlag',
  AUTHORIZATION: 'Authorization',
  ACCEPT_LANGUAGE: 'Accept-Language',
  TOKEN: 'token',
  REFRESH_TOKEN: 'refresh_token',
  LOGIN_SUCCESSFUL: 'Y060012',
  LOGOUT_SUCCESSFUL: 'Y060013',
  PROCESS_OK: 10000
}

export default userConst
