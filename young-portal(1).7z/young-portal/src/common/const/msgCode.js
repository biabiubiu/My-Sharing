const msgCode = {
  YOU_ARE_LOGOUT_ELSEWHERE: 'Y002000',
  TOKEN_EXPIRED: 'Y002001'
}

export default msgCode
