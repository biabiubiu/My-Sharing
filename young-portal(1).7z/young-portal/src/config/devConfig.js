const domain = 'http://localhost:20000'
module.exports = {
  'gateway': {
    target: `${domain}`,
    secure: false,
    changeOrigin: true,
    pathRewrite: {
      '^/gateway': ''
    }
  }
}
