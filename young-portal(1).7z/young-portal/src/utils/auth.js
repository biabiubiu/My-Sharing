import Cookies from 'js-cookie'
import userConst from '@/common/const/userConst'

export function getToken() {
  return Cookies.get(userConst.TOKEN)
}

export function setToken(token) {
  return Cookies.set(userConst.TOKEN, token)
}

export function removeToken() {
  return Cookies.remove(userConst.TOKEN)
}

export function getRefreshToken() {
  return Cookies.get(userConst.REFRESH_TOKEN)
}

export function setRefreshToken(refreshToken) {
  return Cookies.set(userConst.REFRESH_TOKEN, refreshToken)
}

export function removeRefreshToken() {
  return Cookies.remove(userConst.REFRESH_TOKEN)
}

export function getSsoFlag() {
  return Cookies.get(userConst.SSO_FLAG)
}

export function setSsoFlag(ssoFlag) {
  return Cookies.set(userConst.SSO_FLAG, ssoFlag)
}

export function removeSsoFlag() {
  return Cookies.remove(userConst.SSO_FLAG)
}

/**
 * 校验路径path是否在routes的path中
 * @param path
 * @param routes
 */
let flag = false

export function checkExists(path, routes) {
  routes.forEach(r => {
    if (r.path.indexOf(path) > -1) {
      flag = true
      return
    }
    if (r.children) {
      checkExists(path, r.children)
    }
  })

  return flag
}
