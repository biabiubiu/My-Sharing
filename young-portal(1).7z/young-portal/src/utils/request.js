import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import { getSsoFlag, getRefreshToken, getToken } from '@/utils/auth'
import userConst from '@/common/const/userConst'
import msgCode from '@/common/const/msgCode'
import i18n from '@/locale'

// create an axios instance
axios.defaults.withCredentials = true
const service = axios.create({
  // baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  // withCredentials: true, // send cookies when cross-domain requests
  timeout: 5000 // request timeout
})

// request interceptor
service.interceptors.request.use(
  config => {
    // do something before request is sent

    if (store.getters.token) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
      config.headers[userConst.TOKEN] = getToken()
      config.headers[userConst.REFRESH_TOKEN] = getRefreshToken()
      config.headers[userConst.SSO_FLAG] = getSsoFlag()
      config.headers[userConst.ACCEPT_LANGUAGE] = i18n.locale.replace('_', '-')
    }
    return config
  },
  error => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
   */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {
    const res = response.data
    // if the custom code is not 20000, it is judged as an error.
    console.dir(res)
    if (res.code !== userConst.PROCESS_OK) {
      Message({
        type: 'error',
        message: res ? res.msg : response
      })

      // 50008: Illegal token; 50012: Other clients logged in; 50014: Token expired;
      if (res.code === msgCode.YOU_ARE_LOGOUT_ELSEWHERE || res.code === msgCode.TOKEN_EXPIRED) {
        // to re-login
        MessageBox.confirm(res.msg, i18n.t('action.logout.error.title'), {
          confirmButtonText: i18n.t('action.logout.error.confirm'),
          cancelButtonText: i18n.t('action.logout.error.cancel'),
          type: 'warning'
        }).then(() => {
          store.dispatch('user/resetToken').then(() => {
            location.reload()
          })
        })
      }
      return Promise.reject(res.msg)
    } else {
      return response
    }
  },
  error => {
    Message({
      message: error.response.status === 200 ? error.response.data : error.response.statusText,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(error)
  }
)

export default service
