import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

import '@/styles/index.scss' // global css
import App from './App'
import store from './store'
import router from './router'

import '@/icons' // icon
import '@/permission' // permission control
import i18n from '@/locale'

// 加解密工具
import JSEncrypt from 'jsencrypt'
import sec from '@/config/security'

Vue.prototype.$getRsaCode = function(str) { // 注册方法
  // ES6 模板字符串 引用 rsa 公钥
  const encryptStr = new JSEncrypt({
    default_key_size: '2048'
  })
  encryptStr.setPublicKey(sec.PUBLIC_KEY) // 设置 加密公钥
  // 进行加密
  return encryptStr.encrypt(str)
}

// set ElementUI lang to EN
// 如果想要中文版 element-ui，按如下方式声明
Vue.use(ElementUI)
Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
})
