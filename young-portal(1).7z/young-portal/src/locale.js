// 国际化
import Vue from 'vue'
import elemEn from 'element-ui/lib/locale/lang/en'
import youngEn from '@/i18n/lang/en'
import elemZh from 'element-ui/lib/locale/lang/zh-CN'
import youngZh from '@/i18n/lang/zh'
import VueI18n from 'vue-i18n'
import ElementLocale from 'element-ui/lib/locale'

const messages = {
  en_US: {
    ...elemEn,
    ...youngEn
  },
  zh_CN: {
    ...elemZh,
    ...youngZh
  }
}
Vue.use(VueI18n)
const i18n = new VueI18n({
  locale: sessionStorage.getItem('lang') || 'zh_CN',
  messages
})
ElementLocale.i18n((key, value) => i18n.t(key, value))

export default i18n
